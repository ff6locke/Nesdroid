plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nesdroid"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nesdroid"
        minSdk = 21
        targetSdk = 34
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "0.1"
    }

    // A fixed signing key means every new build installs OVER the old one (keeping saves and states).
    signingConfigs {
        create("fixed") {
            storeFile = file("nesdroid.jks")
            storePassword = "nesdroid"
            keyAlias = "nesdroid"
            keyPassword = "nesdroid"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
