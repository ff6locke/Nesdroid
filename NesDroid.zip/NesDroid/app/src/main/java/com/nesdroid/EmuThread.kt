package com.nesdroid

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import com.nesdroid.core.Apu
import com.nesdroid.core.Nes

/** Runs the emulator; the audio buffer's blocking write paces emulation to 60 fps. */
class EmuThread(
    private val nes: Nes,
    private val view: GameView,
    private val saves: SaveStore
) : Thread("emu") {

    @Volatile var running = true
    @Volatile var paused = false
    @Volatile var resetRequested = false
    @Volatile var saveRequested = false
    @Volatile var importRam: ByteArray? = null

    private fun flushSave() {
        if (nes.mapper.ramDirty) {
            nes.mapper.ramDirty = false
            try { saves.save(nes.cart) } catch (ignored: Exception) { nes.mapper.ramDirty = true }
        }
    }

    @Suppress("DEPRECATION")
    private fun createTrack(): AudioTrack? {
        return try {
            val min = AudioTrack.getMinBufferSize(
                Apu.RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (min <= 0) return null
            val t = AudioTrack(
                AudioManager.STREAM_MUSIC, Apu.RATE, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192), AudioTrack.MODE_STREAM
            )
            if (t.state == AudioTrack.STATE_INITIALIZED) t else null
        } catch (ignored: Exception) { null }
    }

    override fun run() {
        val track = createTrack()
        var wasPaused = false
        var dirtyFrames = 0
        var next = System.nanoTime()
        try {
            track?.play()
            while (running) {
                if (paused) {
                    if (!wasPaused) { track?.pause(); flushSave(); wasPaused = true }
                    sleep(40)
                    continue
                }
                if (wasPaused) { wasPaused = false; track?.play(); next = System.nanoTime() }

                if (resetRequested) { resetRequested = false; nes.reset() }
                val imp = importRam
                if (imp != null) {
                    importRam = null
                    val ram = nes.mapper.prgRam
                    java.util.Arrays.fill(ram, 0)
                    System.arraycopy(imp, 0, ram, 0, minOf(imp.size, ram.size))
                    nes.mapper.ramDirty = true
                    flushSave()
                    nes.reset()
                }
                if (saveRequested) { saveRequested = false; nes.mapper.ramDirty = true; flushSave() }

                nes.buttons[0] = view.buttons
                nes.runFrame()
                view.present(nes.ppu.fb)

                val n = nes.apu.sampleCount
                if (track != null) {
                    if (n > 0) track.write(nes.apu.samples, 0, n)
                } else {
                    next += 16_639_267L
                    val d = next - System.nanoTime()
                    if (d > 0) sleep(d / 1_000_000, (d % 1_000_000).toInt())
                    else if (d < -100_000_000L) next = System.nanoTime()
                }
                nes.apu.sampleCount = 0

                if (nes.mapper.ramDirty) {
                    if (++dirtyFrames >= 90) { flushSave(); dirtyFrames = 0 }
                }
            }
        } catch (ignored: InterruptedException) {
        } finally {
            flushSave()
            try { track?.stop() } catch (ignored: Exception) {}
            track?.release()
        }
    }
}
