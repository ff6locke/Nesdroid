package com.nesdroid

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import com.nesdroid.core.Apu
import com.nesdroid.core.Nes
import java.util.concurrent.locks.LockSupport

/**
 * Runs the emulator. Video is paced by the wall clock (60.1 fps); audio is fed
 * without blocking so uneven audio-driver wakeups can't cause frame judder.
 */
class EmuThread(
    private val nes: Nes,
    private val view: GameView,
    private val saves: SaveStore
) : Thread("emu") {

    @Volatile var running = true
    @Volatile var paused = false
    @Volatile var resetRequested = false
    @Volatile var saveRequested = false
    @Volatile var fastForward = false
    @Volatile var importRam: ByteArray? = null
    @Volatile var stateOp = 0      // 0 none, 1 save, 2 load
    @Volatile var stateSlot = 1
    var onMessage: ((String) -> Unit)? = null

    private fun flushSave() {
        if (nes.mapper.ramDirty) {
            nes.mapper.ramDirty = false
            try { saves.save(nes.cart) } catch (ignored: Exception) { nes.mapper.ramDirty = true }
        }
    }

    @Suppress("DEPRECATION")
    private fun createTrack(): AudioTrack? {
        return try {
            val min = AudioTrack.getMinBufferSize(
                Apu.RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (min <= 0) return null
            val t = AudioTrack(
                AudioManager.STREAM_MUSIC, Apu.RATE, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 12288), AudioTrack.MODE_STREAM
            )
            if (t.state == AudioTrack.STATE_INITIALIZED) t else null
        } catch (ignored: Exception) { null }
    }

    private fun handleState(op: Int, slot: Int) {
        try {
            if (op == 1) {
                saves.writeState(nes.cart, slot, nes.saveState())
                onMessage?.invoke("State saved to slot $slot")
            } else {
                val data = saves.readState(nes.cart, slot)
                if (data == null) {
                    onMessage?.invoke("Slot $slot is empty")
                } else if (nes.loadState(data)) {
                    nes.apu.sampleCount = 0
                    view.present(nes.ppu.fb)
                    onMessage?.invoke("State loaded from slot $slot")
                } else {
                    onMessage?.invoke("That state is from a different ROM or app version")
                }
            }
        } catch (e: Exception) {
            onMessage?.invoke("State operation failed")
            if (op == 2) nes.reset()
        }
    }

    /** Pre-fill ~50 ms of silence so small timing hiccups don't underrun the audio buffer. */
    private fun prime(track: AudioTrack?) {
        if (track == null) return
        try {
            val z = ShortArray(PRIME_SAMPLES)
            track.write(z, 0, z.size)
        } catch (ignored: Exception) {}
    }

    override fun run() {
        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (ignored: Exception) {}
        val track = createTrack()
        var wasPaused = false
        var ffActive = false
        var dirtyFrames = 0
        var next = System.nanoTime()
        var statFrames = 0
        var statStart = next
        try {
            prime(track)
            track?.play()
            while (running) {
                if (paused) {
                    if (!wasPaused) { track?.pause(); flushSave(); saves.waitIdle(); wasPaused = true }
                    sleep(40)
                    continue
                }
                if (wasPaused) {
                    wasPaused = false
                    if (!ffActive) track?.play()
                    next = System.nanoTime()
                }

                if (resetRequested) { resetRequested = false; nes.reset() }
                val imp = importRam
                if (imp != null) {
                    importRam = null
                    val ram = nes.mapper.prgRam
                    java.util.Arrays.fill(ram, 0)
                    System.arraycopy(imp, 0, ram, 0, minOf(imp.size, ram.size))
                    nes.mapper.ramDirty = true
                    flushSave()
                    nes.reset()
                }
                if (saveRequested) { saveRequested = false; nes.mapper.ramDirty = true; flushSave() }

                val sop = stateOp
                if (sop != 0) {
                    stateOp = 0
                    handleState(sop, stateSlot)
                    next = System.nanoTime()
                }

                nes.buttons[0] = view.buttons
                if (fastForward) {
                    if (!ffActive) {
                        ffActive = true
                        try { track?.pause(); track?.flush() } catch (ignored: Exception) {}
                    }
                    for (k in 0 until FF_SPEED) { nes.runFrame(); nes.apu.sampleCount = 0 }
                } else {
                    if (ffActive) {
                        ffActive = false
                        prime(track)
                        track?.play()
                        next = System.nanoTime()
                    }
                    nes.runFrame()
                    val n = nes.apu.sampleCount
                    if (track != null && n > 0) {
                        if (Build.VERSION.SDK_INT >= 23) track.write(nes.apu.samples, 0, n, AudioTrack.WRITE_NON_BLOCKING)
                        else track.write(nes.apu.samples, 0, n)
                    }
                    nes.apu.sampleCount = 0
                }
                view.present(nes.ppu.fb)

                if (nes.mapper.ramDirty && ++dirtyFrames >= 90) { flushSave(); dirtyFrames = 0 }

                statFrames++
                val now = System.nanoTime()
                if (now - statStart >= 1_000_000_000L) {
                    view.emuFps = statFrames * (if (ffActive) FF_SPEED else 1)
                    statFrames = 0
                    statStart = now
                }

                // Pace to the wall clock.
                next += FRAME_NS
                while (running) {
                    val rem = next - System.nanoTime()
                    if (rem <= 0) break
                    LockSupport.parkNanos(rem)
                }
                if (System.nanoTime() - next > 50_000_000L) next = System.nanoTime() // fell behind: resync
            }
        } catch (ignored: InterruptedException) {
        } finally {
            flushSave()
            saves.waitIdle()
            try { track?.stop() } catch (ignored: Exception) {}
            track?.release()
        }
    }

    companion object {
        /** Emulated frames per displayed frame while fast-forwarding. */
        const val FF_SPEED = 4
        const val FRAME_NS = 16_639_267L
        const val PRIME_SAMPLES = 2200
    }
}
