package com.nesdroid.core

import java.io.DataInputStream
import java.io.DataOutputStream

/** Ties CPU, PPU, APU, cartridge and controllers together. */
class Nes(val cart: Cartridge) {
    val mapper: Mapper = cart.mapper
    private val ram = ByteArray(0x800)
    val ppu = Ppu(mapper)
    val apu = Apu()
    val cpu = Cpu(this)

    /** Pad state: bit0 A, 1 B, 2 Select, 3 Start, 4 Up, 5 Down, 6 Left, 7 Right. */
    val buttons = IntArray(2)
    private val shiftReg = IntArray(2)
    private var strobe = false

    init { cpu.reset() }

    fun reset() {
        ppu.reset()
        apu.reset()
        cpu.reset()
    }

    fun read(addr: Int): Int = when {
        addr < 0x2000 -> ram[addr and 0x7FF].toInt() and 0xFF
        addr < 0x4000 -> ppu.readReg(addr and 7)
        addr < 0x4020 -> when (addr) {
            0x4015 -> apu.readStatus()
            0x4016 -> readPad(0)
            0x4017 -> readPad(1)
            else -> 0
        }
        else -> mapper.cpuRead(addr)
    }

    fun write(addr: Int, v: Int) {
        when {
            addr < 0x2000 -> ram[addr and 0x7FF] = v.toByte()
            addr < 0x4000 -> ppu.writeReg(addr and 7, v)
            addr < 0x4020 -> when {
                addr == 0x4014 -> dma(v)
                addr == 0x4016 -> {
                    strobe = (v and 1) != 0
                    if (strobe) { shiftReg[0] = buttons[0]; shiftReg[1] = buttons[1] }
                }
                else -> apu.write(addr, v)
            }
            else -> mapper.cpuWrite(addr, v)
        }
    }

    private fun readPad(i: Int): Int {
        if (strobe) return (buttons[i] and 1) or 0x40
        val r = shiftReg[i] and 1
        shiftReg[i] = (shiftReg[i] shr 1) or 0x80
        return r or 0x40
    }

    private fun dma(page: Int) {
        val base = page shl 8
        for (i in 0 until 256) ppu.oam[(ppu.oamAddr + i) and 0xFF] = read(base + i)
        cpu.stall += 513
    }

    /** Serializes the complete machine state (gzip-compressed). Call between frames. */
    fun saveState(): ByteArray {
        val bos = java.io.ByteArrayOutputStream(64 * 1024)
        DataOutputStream(java.util.zip.GZIPOutputStream(bos)).use { o ->
            o.writeInt(STATE_MAGIC); o.writeInt(STATE_VERSION); o.writeUTF(cart.crc)
            o.write(ram)
            o.writeInt(shiftReg[0]); o.writeInt(shiftReg[1]); o.writeBoolean(strobe)
            cpu.saveState(o); ppu.saveState(o); apu.saveState(o); mapper.saveState(o)
        }
        return bos.toByteArray()
    }

    /** Restores a state made by saveState(); returns false if it belongs to another ROM/version. */
    fun loadState(data: ByteArray): Boolean {
        DataInputStream(java.util.zip.GZIPInputStream(java.io.ByteArrayInputStream(data))).use { i ->
            if (i.readInt() != STATE_MAGIC || i.readInt() != STATE_VERSION) return false
            if (i.readUTF() != cart.crc) return false
            i.readFully(ram)
            shiftReg[0] = i.readInt(); shiftReg[1] = i.readInt(); strobe = i.readBoolean()
            cpu.loadState(i); ppu.loadState(i); apu.loadState(i); mapper.loadState(i)
        }
        return true
    }

    /** Runs until the PPU enters vblank (one video frame). */
    fun runFrame() {
        val start = ppu.frame
        while (ppu.frame == start) {
            val c = cpu.step()
            apu.cycles(c)
            mapper.cpuCycles(c)
            ppu.tick(c * 3)
        }
    }

    companion object {
        private const val STATE_MAGIC = 0x4E445331 // "NDS1"
        private const val STATE_VERSION = 2
    }
}
