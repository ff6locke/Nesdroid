package com.nesdroid.core

private val LEN = intArrayOf(
    10, 254, 20, 2, 40, 4, 80, 6, 160, 8, 60, 10, 14, 12, 26, 14,
    12, 16, 24, 18, 48, 20, 96, 22, 192, 24, 72, 26, 16, 28, 32, 30
)
private val DUTY = arrayOf(
    intArrayOf(0, 1, 0, 0, 0, 0, 0, 0),
    intArrayOf(0, 1, 1, 0, 0, 0, 0, 0),
    intArrayOf(0, 1, 1, 1, 1, 0, 0, 0),
    intArrayOf(1, 0, 0, 1, 1, 1, 1, 1)
)
private val NOISE_PERIOD = intArrayOf(4, 8, 16, 32, 64, 96, 128, 160, 202, 254, 380, 508, 762, 1016, 2034, 4068)
private val TRI_SEQ = IntArray(32) { if (it < 16) 15 - it else it - 16 }

private class Env {
    var start = false
    var div = 0
    var decay = 0
    fun clock(period: Int, loop: Boolean) {
        if (start) {
            start = false; decay = 15; div = period
        } else if (div == 0) {
            div = period
            if (decay > 0) decay-- else if (loop) decay = 15
        } else div--
    }
}

private class Pulse(private val first: Boolean) {
    var enabled = false
    var duty = 0
    var halt = false
    var constVol = false
    var vol = 0
    var period = 0
    var timer = 0
    var seq = 0
    var length = 0
    val env = Env()
    var swEnable = false
    var swPeriod = 0
    var swNeg = false
    var swShift = 0
    var swReload = false
    var swDiv = 0

    fun write(r: Int, d: Int) {
        when (r) {
            0 -> { duty = d shr 6; halt = (d and 0x20) != 0; constVol = (d and 0x10) != 0; vol = d and 15 }
            1 -> { swEnable = (d and 0x80) != 0; swPeriod = (d shr 4) and 7; swNeg = (d and 8) != 0; swShift = d and 7; swReload = true }
            2 -> period = (period and 0x700) or d
            3 -> {
                period = (period and 0xFF) or ((d and 7) shl 8)
                if (enabled) length = LEN[d shr 3]
                seq = 0
                env.start = true
            }
        }
    }

    fun clockTimer() { if (timer == 0) { timer = period; seq = (seq + 1) and 7 } else timer-- }
    fun clockEnv() = env.clock(vol, halt)
    fun clockLen() { if (!halt && length > 0) length-- }

    private fun target(): Int {
        val ch = period shr swShift
        return if (swNeg) period - ch - (if (first) 1 else 0) else period + ch
    }

    fun clockSweep() {
        if (swDiv == 0 && swEnable && swShift != 0 && period >= 8 && target() <= 0x7FF) period = target()
        if (swDiv == 0 || swReload) { swDiv = swPeriod; swReload = false } else swDiv--
    }

    fun out(): Int {
        if (length == 0 || DUTY[duty][seq] == 0 || period < 8 || target() > 0x7FF) return 0
        return if (constVol) vol else env.decay
    }
}

private class Tri {
    var enabled = false
    var control = false
    var linearReload = 0
    var linear = 0
    var linearFlag = false
    var period = 0
    var timer = 0
    var seq = 0
    var length = 0

    fun write(r: Int, d: Int) {
        when (r) {
            0 -> { control = (d and 0x80) != 0; linearReload = d and 0x7F }
            2 -> period = (period and 0x700) or d
            3 -> {
                period = (period and 0xFF) or ((d and 7) shl 8)
                if (enabled) length = LEN[d shr 3]
                linearFlag = true
            }
        }
    }

    fun clockTimer() {
        if (timer == 0) {
            timer = period
            if (length > 0 && linear > 0) seq = (seq + 1) and 31
        } else timer--
    }
    fun clockLinear() {
        if (linearFlag) linear = linearReload else if (linear > 0) linear--
        if (!control) linearFlag = false
    }
    fun clockLen() { if (!control && length > 0) length-- }
    fun out(): Int = TRI_SEQ[seq]
}

private class Noise {
    var enabled = false
    var halt = false
    var constVol = false
    var vol = 0
    var mode = false
    var period = 4
    var timer = 0
    var shift = 1
    var length = 0
    val env = Env()

    fun write(r: Int, d: Int) {
        when (r) {
            0 -> { halt = (d and 0x20) != 0; constVol = (d and 0x10) != 0; vol = d and 15 }
            2 -> { mode = (d and 0x80) != 0; period = NOISE_PERIOD[d and 15] }
            3 -> { if (enabled) length = LEN[d shr 3]; env.start = true }
        }
    }

    fun clockTimer() {
        if (timer == 0) {
            timer = period
            val fb = (shift and 1) xor ((shift shr (if (mode) 6 else 1)) and 1)
            shift = (shift shr 1) or (fb shl 14)
        } else timer--
    }
    fun clockEnv() = env.clock(vol, halt)
    fun clockLen() { if (!halt && length > 0) length-- }
    fun out(): Int = if ((shift and 1) != 0 || length == 0) 0 else if (constVol) vol else env.decay
}

/**
 * APU: 2 pulse + triangle + noise, averaged down to 44.1 kHz mono.
 * (DMC samples and frame IRQ are not emulated yet.)
 */
class Apu {
    private val p1 = Pulse(true)
    private val p2 = Pulse(false)
    private val tri = Tri()
    private val noise = Noise()
    private var frameCycle = 0
    private var mode5 = false
    private var odd = false
    private var sumP = 0
    private var sumT = 0
    private var sumN = 0
    private var cnt = 0
    private var acc = 0.0
    private var hpIn = 0f
    private var hpOut = 0f

    val samples = ShortArray(4096)
    var sampleCount = 0

    fun reset() {
        write(0x4015, 0)
        frameCycle = 0
    }

    fun write(addr: Int, d: Int) {
        when (addr) {
            in 0x4000..0x4003 -> p1.write(addr - 0x4000, d)
            in 0x4004..0x4007 -> p2.write(addr - 0x4004, d)
            in 0x4008..0x400B -> tri.write(addr - 0x4008, d)
            in 0x400C..0x400F -> noise.write(addr - 0x400C, d)
            0x4015 -> {
                p1.enabled = (d and 1) != 0; if (!p1.enabled) p1.length = 0
                p2.enabled = (d and 2) != 0; if (!p2.enabled) p2.length = 0
                tri.enabled = (d and 4) != 0; if (!tri.enabled) tri.length = 0
                noise.enabled = (d and 8) != 0; if (!noise.enabled) noise.length = 0
            }
            0x4017 -> {
                mode5 = (d and 0x80) != 0
                frameCycle = 0
                if (mode5) { quarter(); half() }
            }
        }
    }

    fun readStatus(): Int =
        (if (p1.length > 0) 1 else 0) or (if (p2.length > 0) 2 else 0) or
            (if (tri.length > 0) 4 else 0) or (if (noise.length > 0) 8 else 0)

    private fun quarter() {
        p1.clockEnv(); p2.clockEnv(); noise.clockEnv(); tri.clockLinear()
    }
    private fun half() {
        p1.clockLen(); p2.clockLen(); tri.clockLen(); noise.clockLen()
        p1.clockSweep(); p2.clockSweep()
    }

    fun cycles(n: Int) {
        var i = 0
        while (i < n) { cycle(); i++ }
    }

    private fun cycle() {
        frameCycle++
        if (mode5) {
            when (frameCycle) {
                7457 -> quarter()
                14913 -> { quarter(); half() }
                22371 -> quarter()
                37281 -> { quarter(); half() }
            }
            if (frameCycle >= 37282) frameCycle = 0
        } else {
            when (frameCycle) {
                7457 -> quarter()
                14913 -> { quarter(); half() }
                22371 -> quarter()
                29829 -> { quarter(); half() }
            }
            if (frameCycle >= 29830) frameCycle = 0
        }
        odd = !odd
        if (odd) { p1.clockTimer(); p2.clockTimer(); noise.clockTimer() }
        tri.clockTimer()

        if ((frameCycle and 3) == 0) { // sample channel levels every 4th cycle
            sumP += p1.out() + p2.out()
            sumT += tri.out()
            sumN += noise.out()
            cnt++
        }
        acc += 1.0
        if (acc >= CPS) { acc -= CPS; emit() }
    }

    private fun emit() {
        val c = if (cnt == 0) 1f else cnt.toFloat()
        val mix = 0.00752f * sumP / c + 0.00851f * sumT / c + 0.00494f * sumN / c
        sumP = 0; sumT = 0; sumN = 0; cnt = 0
        hpOut = mix - hpIn + 0.996f * hpOut
        hpIn = mix
        val s = (hpOut * 2f * 30000f).toInt().coerceIn(-32768, 32767)
        if (sampleCount < samples.size) samples[sampleCount++] = s.toShort()
    }

    companion object {
        const val RATE = 44100
        const val CPS = 1789773.0 / RATE
    }
}
