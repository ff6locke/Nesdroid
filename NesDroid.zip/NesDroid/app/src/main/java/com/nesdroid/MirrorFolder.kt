package com.nesdroid

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document

/**
 * A folder the user picked with the system file picker (Storage Access Framework).
 * Files there survive uninstalling the app, so saves are mirrored into it.
 */
class MirrorFolder(private val cr: ContentResolver, private val tree: Uri) {
    class Entry(val docId: String, val modified: Long)

    private val parentId = DocumentsContract.getTreeDocumentId(tree)
    private val parentUri = DocumentsContract.buildDocumentUriUsingTree(tree, parentId)

    private fun docUri(id: String) = DocumentsContract.buildDocumentUriUsingTree(tree, id)

    /** File name -> entry for every file directly inside the folder. */
    fun list(): Map<String, Entry> {
        val out = HashMap<String, Entry>()
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        cr.query(
            children,
            arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_LAST_MODIFIED),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) out[c.getString(1)] = Entry(c.getString(0), c.getLong(2))
        }
        return out
    }

    fun read(e: Entry): ByteArray? = cr.openInputStream(docUri(e.docId))?.use { it.readBytes() }

    /** Creates or overwrites [name] with [data]. */
    fun put(name: String, data: ByteArray) {
        val existing = list()[name]
        val uri = if (existing != null) docUri(existing.docId)
        else DocumentsContract.createDocument(cr, parentUri, "application/octet-stream", name) ?: return
        cr.openOutputStream(uri, "wt")?.use { it.write(data) }
    }
}
