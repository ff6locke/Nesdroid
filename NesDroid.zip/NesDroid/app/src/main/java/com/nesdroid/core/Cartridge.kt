package com.nesdroid.core

import java.util.zip.CRC32

class UnsupportedRomException(msg: String) : Exception(msg)

/** Parses an iNES (.nes) image. */
class Cartridge(rom: ByteArray) {
    val prg: ByteArray
    val chr: ByteArray
    val chrIsRam: Boolean
    val mapperId: Int
    val battery: Boolean
    val fourScreen: Boolean
    val mirroring: Int // 0 = horizontal, 1 = vertical
    val crc: String
    val mapper: Mapper

    init {
        if (rom.size < 16 || rom[0] != 'N'.code.toByte() || rom[1] != 'E'.code.toByte() ||
            rom[2] != 'S'.code.toByte() || rom[3] != 0x1A.toByte()
        ) throw UnsupportedRomException("Not an iNES (.nes) file")

        val prgBanks = rom[4].toInt() and 0xFF
        val chrBanks = rom[5].toInt() and 0xFF
        val f6 = rom[6].toInt() and 0xFF
        val f7 = rom[7].toInt() and 0xFF
        battery = (f6 and 2) != 0
        fourScreen = (f6 and 8) != 0
        mirroring = if ((f6 and 1) != 0) 1 else 0
        mapperId = (f6 shr 4) or (f7 and 0xF0)

        var off = 16 + (if ((f6 and 4) != 0) 512 else 0)
        val prgSize = prgBanks * 0x4000
        if (prgSize == 0 || off + prgSize > rom.size) throw UnsupportedRomException("ROM file is truncated")
        prg = rom.copyOfRange(off, off + prgSize)
        off += prgSize

        if (chrBanks == 0) {
            chr = ByteArray(0x2000)
            chrIsRam = true
        } else {
            val size = chrBanks * 0x2000
            chr = ByteArray(size)
            System.arraycopy(rom, off, chr, 0, minOf(size, rom.size - off).coerceAtLeast(0))
            chrIsRam = false
        }

        val c = CRC32()
        c.update(rom, 16, rom.size - 16)
        crc = String.format("%08x", c.value)

        mapper = when (mapperId) {
            0 -> Mapper0(this)
            1 -> Mapper1(this)
            2 -> Mapper2(this)
            3 -> Mapper3(this)
            4 -> Mapper4(this)
            7 -> Mapper7(this)
            16 -> MapperBandai(this, false)
            159 -> MapperBandai(this, true)
            else -> throw UnsupportedRomException("Mapper $mapperId is not supported yet")
        }
    }
}
