package com.nesdroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import com.nesdroid.core.Cartridge
import com.nesdroid.core.Nes
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private val reqRom = 1
    private val reqExport = 2
    private val reqImport = 3

    private lateinit var view: GameView
    private lateinit var saves: SaveStore
    private lateinit var prefs: SharedPreferences
    private var emu: EmuThread? = null
    private var nes: Nes? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        view = GameView(this)
        view.onMenu = { showMenu() }
        view.onFastForward = { on -> emu?.fastForward = on }
        setContentView(view)
        saves = SaveStore(java.io.File(filesDir, "saves"))
        prefs = getSharedPreferences("nes", MODE_PRIVATE)
        prefs.getString("lastRom", null)?.let { loadRom(Uri.parse(it), silent = true) }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onPause() { super.onPause(); emu?.paused = true }
    override fun onResume() { super.onResume(); emu?.paused = false }
    override fun onDestroy() { stopEmu(); super.onDestroy() }

    private fun stopEmu() {
        emu?.let { it.running = false; it.interrupt(); it.join(2000) }
        emu = null
    }

    private fun showMenu() {
        val items = arrayOf("Open ROM\u2026", "Reset", "Save now", "Export save file\u2026", "Import save file\u2026")
        AlertDialog.Builder(this).setTitle("NesDroid").setItems(items) { _, i ->
            when (i) {
                0 -> pick(reqRom)
                1 -> { emu?.resetRequested = true }
                2 -> { emu?.saveRequested = true; toast("Saved") }
                3 -> nes?.let {
                    startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE); type = "application/octet-stream"
                        putExtra(Intent.EXTRA_TITLE, "${it.cart.crc}.sav")
                    }, reqExport)
                } ?: toast("Load a ROM first")
                4 -> if (nes != null) pick(reqImport) else toast("Load a ROM first")
            }
        }.show()
    }

    private fun pick(req: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            if (req == reqRom) addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        try {
            when (requestCode) {
                reqRom -> {
                    try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (ignored: Exception) {}
                    loadRom(uri, silent = false)
                }
                reqExport -> nes?.let { n ->
                    contentResolver.openOutputStream(uri)?.use { it.write(n.mapper.prgRam.copyOf()) }
                    toast("Save exported")
                }
                reqImport -> {
                    val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    emu?.importRam = bytes
                    toast("Save imported \u2013 game reset")
                }
            }
        } catch (e: Exception) {
            toast(e.message ?: "Operation failed")
        }
    }

    private fun loadRom(uri: Uri, silent: Boolean) {
        stopEmu()
        try {
            var bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) bytes = unzip(bytes)
            val cart = Cartridge(bytes)
            saves.load(cart)
            val n = Nes(cart)
            nes = n
            prefs.edit().putString("lastRom", uri.toString()).apply()
            view.hasGame = true
            view.ffOn = false
            val t = EmuThread(n, view, saves)
            emu = t
            t.start()
            if (!silent) toast("Mapper ${cart.mapperId}" + if (cart.battery) ", battery save" else "")
        } catch (e: Exception) {
            view.hasGame = false
            nes = null
            if (!silent) toast(e.message ?: "Could not load ROM")
            view.present(null)
        }
    }

    private fun unzip(data: ByteArray): ByteArray {
        ZipInputStream(ByteArrayInputStream(data)).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.name.lowercase().endsWith(".nes")) return z.readBytes()
            }
        }
        throw Exception("No .nes file found in the zip")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
