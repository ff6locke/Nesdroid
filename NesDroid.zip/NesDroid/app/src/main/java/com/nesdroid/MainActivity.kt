package com.nesdroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import com.nesdroid.core.Cartridge
import com.nesdroid.core.Nes
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private val reqRom = 1
    private val reqExport = 2
    private val reqImport = 3

    private lateinit var view: GameView
    private lateinit var saves: SaveStore
    private lateinit var prefs: SharedPreferences
    private var emu: EmuThread? = null
    private var nes: Nes? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        view = GameView(this)
        view.onMenu = { showMenu() }
        view.onFastForward = { on -> emu?.fastForward = on }
        setContentView(view)
        saves = SaveStore(java.io.File(filesDir, "saves"))
        prefs = getSharedPreferences("nes", MODE_PRIVATE)
        view.slot = prefs.getInt("slot", 1).coerceIn(1, 10)
        view.onSlotChange = { s -> prefs.edit().putInt("slot", s).apply() }
        view.onQuickSave = { quickState(1) }
        view.onQuickLoad = { quickState(2) }
        prefs.getString("lastRom", null)?.let { loadRom(Uri.parse(it), silent = true) }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onPause() { super.onPause(); emu?.paused = true }
    override fun onResume() { super.onResume(); emu?.paused = false }
    override fun onDestroy() { stopEmu(); super.onDestroy() }

    private fun stopEmu() {
        emu?.let { it.running = false; it.interrupt(); it.join(2000) }
        emu = null
    }

    private fun showMenu() {
        val items = arrayOf(
            "Open ROM\u2026", "Save state\u2026", "Load state\u2026", "Reset", "Flush battery save",
            "Export save file\u2026", "Import save file\u2026", "Info / save debug",
            if (view.showStats) "Hide FPS" else "Show FPS"
        )
        AlertDialog.Builder(this).setTitle("NesDroid").setItems(items) { _, i ->
            when (i) {
                0 -> pick(reqRom)
                1 -> pickSlot(true)
                2 -> pickSlot(false)
                3 -> { emu?.resetRequested = true }
                4 -> { emu?.saveRequested = true; toast("Battery save flushed") }
                5 -> nes?.let {
                    startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE); type = "application/octet-stream"
                        putExtra(Intent.EXTRA_TITLE, "${it.cart.crc}.sav")
                    }, reqExport)
                } ?: toast("Load a ROM first")
                6 -> if (nes != null) pick(reqImport) else toast("Load a ROM first")
                7 -> showInfo()
                8 -> { view.showStats = !view.showStats; view.present(null) }
            }
        }.show()
    }

    private fun selectSlot(slot: Int) {
        view.slot = slot
        prefs.edit().putInt("slot", slot).apply()
        view.present(null)
    }

    /** One-tap save (op 1) or load (op 2) using the slot chosen on screen. */
    private fun quickState(op: Int) {
        val t = emu
        if (t == null) { toast("Load a ROM first"); return }
        t.stateSlot = view.slot
        t.stateOp = op
    }

    /** Shows the 10 save-state slots; [save] chooses between saving and loading. */
    private fun pickSlot(save: Boolean) {
        val n = nes
        if (n == null) { toast("Load a ROM first"); return }
        val fmt = java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT)
        val labels = Array(10) { idx ->
            val t = saves.stateTime(n.cart, idx + 1)
            "Slot ${idx + 1} \u2013 " + (if (t == 0L) "empty" else fmt.format(java.util.Date(t)))
        }
        AlertDialog.Builder(this).setTitle(if (save) "Save state" else "Load state").setItems(labels) { _, i ->
            val slot = i + 1
            if (!save && saves.stateTime(n.cart, slot) == 0L) {
                toast("Slot $slot is empty")
            } else {
                selectSlot(slot)
                emu?.let { it.stateSlot = slot; it.stateOp = if (save) 1 else 2 }
            }
        }.show()
    }

    private fun showInfo() {
        val n = nes
        val msg = if (n == null) "No ROM loaded" else {
            val c = n.cart
            "Mapper ${c.mapperId}\n" +
                "PRG ${c.prg.size / 1024}K, CHR ${c.chr.size / 1024}K" + (if (c.chrIsRam) " (RAM)" else "") + "\n" +
                "Battery flag in header: " + (if (c.battery) "yes" else "no") + "\n" +
                "Save size: ${n.mapper.saveSize} bytes\n" +
                saves.info(c) + "\n" +
                "Unsaved changes: ${n.mapper.ramDirty}\n" +
                n.mapper.debugInfo()
        }
        AlertDialog.Builder(this).setTitle("ROM / save info").setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun pick(req: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            if (req == reqRom) addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        try {
            when (requestCode) {
                reqRom -> {
                    try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (ignored: Exception) {}
                    loadRom(uri, silent = false)
                }
                reqExport -> nes?.let { n ->
                    contentResolver.openOutputStream(uri)?.use { it.write(n.mapper.prgRam.copyOf(n.mapper.saveSize)) }
                    toast("Save exported")
                }
                reqImport -> {
                    val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    emu?.importRam = bytes
                    toast("Save imported \u2013 game reset")
                }
            }
        } catch (e: Exception) {
            toast(e.message ?: "Operation failed")
        }
    }

    private fun loadRom(uri: Uri, silent: Boolean) {
        stopEmu()
        try {
            var bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) bytes = unzip(bytes)
            val cart = Cartridge(bytes)
            saves.load(cart)
            val n = Nes(cart)
            nes = n
            prefs.edit().putString("lastRom", uri.toString()).apply()
            view.hasGame = true
            view.ffOn = false
            val t = EmuThread(n, view, saves)
            emu = t
            t.onMessage = { m -> runOnUiThread { toast(m) } }
            t.start()
            if (!silent) toast("Mapper ${cart.mapperId}" + if (cart.battery) ", battery save" else "")
        } catch (e: Exception) {
            view.hasGame = false
            nes = null
            if (!silent) toast(e.message ?: "Could not load ROM")
            view.present(null)
        }
    }

    private fun unzip(data: ByteArray): ByteArray {
        ZipInputStream(ByteArrayInputStream(data)).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.name.lowercase().endsWith(".nes")) return z.readBytes()
            }
        }
        throw Exception("No .nes file found in the zip")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
