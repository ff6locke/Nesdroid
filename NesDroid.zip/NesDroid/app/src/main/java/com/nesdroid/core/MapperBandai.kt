package com.nesdroid.core

import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Bandai FCG / LZ93D50 boards (iNES mappers 16 and 159).
 * Used by the Dragon Ball Z Famicom games; saves live in a serial EEPROM
 * (24C02 for mapper 16, 24C01 for mapper 159) which is stored in the first bytes of prgRam
 * so it flows through the normal save-file / export / import code.
 */
class MapperBandai(c: Cartridge, private val forceC01: Boolean) : Mapper(c) {
    private val eeprom = Eeprom(prgRam, forceC01, !forceC01) { ramDirty = true }
    private val chrRegs = IntArray(8)
    private var prgBank = 0
    private var irqEnable = false
    private var counter = 0
    private var latch = 0

    override fun saveExtra(o: DataOutputStream) {
        for (r in chrRegs) o.writeInt(r)
        o.writeInt(prgBank); o.writeBoolean(irqEnable); o.writeInt(counter); o.writeInt(latch)
        eeprom.saveState(o)
    }
    override fun loadExtra(i: DataInputStream) {
        for (k in chrRegs.indices) chrRegs[k] = i.readInt()
        prgBank = i.readInt(); irqEnable = i.readBoolean(); counter = i.readInt(); latch = i.readInt()
        eeprom.loadState(i)
    }

    override val saveSize: Int
        get() = if (forceC01) 128 else 256

    private var regDWrites = 0

    override fun debugInfo(): String =
        "EEPROM " + (if (eeprom.is01) "24C01" else "24C02") + (if (eeprom.detected) "" else " (not detected yet)") + ": register writes=$regDWrites, starts=${eeprom.starts}, " +
            "bytes in=${eeprom.rxBytes}, bytes out=${eeprom.txBytes}, data writes=${eeprom.writes}"

    init {
        java.util.Arrays.fill(prgRam, 0, saveSize, 0xFF.toByte()) // blank EEPROM
    }

    override fun cpuRead(addr: Int): Int =
        if (addr >= 0x8000) prgRead(addr)
        else if (addr >= 0x6000) (eeprom.out shl 4) // bit 4 = EEPROM data out
        else 0

    // Registers are mirrored at $6000-$7FFF (FCG-1/2) and $8000-$FFFF (LZ93D50).
    override fun cpuWrite(addr: Int, v: Int) {
        if (addr >= 0x6000) reg(addr and 0x0F, v and 0xFF)
    }

    override fun regWrite(addr: Int, v: Int) = reg(addr and 0x0F, v and 0xFF)

    private fun reg(r: Int, v: Int) {
        when (r) {
            in 0..7 -> chrRegs[r] = v
            8 -> prgBank = v and 0x0F
            9 -> mirroring = when (v and 3) { 0 -> 1; 1 -> 0; 2 -> 2; else -> 3 }
            0xA -> { irq = false; irqEnable = (v and 1) != 0; counter = latch }
            0xB -> latch = (latch and 0xFF00) or v
            0xC -> latch = (latch and 0x00FF) or (v shl 8)
            0xD -> { regDWrites++; eeprom.write((v shr 5) and 1, (v shr 6) and 1) } // SCL = bit 5, SDA = bit 6
        }
    }

    override fun cpuCycles(n: Int) {
        if (!irqEnable) return
        if (counter in 1..n) irq = true
        counter = (counter - n) and 0xFFFF
    }

    override fun prgRead(addr: Int): Int {
        val n16 = prg.size / 0x4000
        val bank = if (addr < 0xC000) prgBank % n16 else n16 - 1
        return prg[bank * 0x4000 + (addr and 0x3FFF)].toInt() and 0xFF
    }

    override fun chrIndex(addr: Int): Int {
        if (cart.chrIsRam) return addr and 0x1FFF
        return (chrRegs[(addr shr 10) and 7] % (chr.size / 0x400)) * 0x400 + (addr and 0x3FF)
    }
}

/** Minimal 24C01 / 24C02 serial (I2C-style) EEPROM. */
class Eeprom(private val data: ByteArray, startIs01: Boolean, auto: Boolean, private val onWrite: () -> Unit) {
    /** Chip type. With [auto], it is detected from the first byte the game sends (0xA0/0xA1 = 24C02, else 24C01). */
    var is01 = startIs01
        private set
    var detected = !auto
        private set
    private var mask = if (startIs01) 0x7F else 0xFF

    var out = 1
        private set
    var starts = 0
    var rxBytes = 0
    var txBytes = 0
    var writes = 0
    private var scl = 0
    private var sda = 1
    private var phase = 0       // 0 idle, 1 receiving bits, 2 ACK, 3 sending bits, 4 master ACK
    private var rxKind = 0      // 0 first byte, 1 word address (24C02), 2 data
    private var afterAck = 0    // 0 none, 1 receive more, 2 start reading
    private var bits = 0
    private var shift = 0
    private var addr = 0
    private var cur = 0
    private var continueRead = false

    fun saveState(o: DataOutputStream) {
        o.writeBoolean(is01); o.writeBoolean(detected); o.writeInt(mask)
        o.writeInt(out); o.writeInt(scl); o.writeInt(sda); o.writeInt(phase); o.writeInt(rxKind)
        o.writeInt(afterAck); o.writeInt(bits); o.writeInt(shift); o.writeInt(addr); o.writeInt(cur)
        o.writeBoolean(continueRead)
    }

    fun loadState(i: DataInputStream) {
        is01 = i.readBoolean(); detected = i.readBoolean(); mask = i.readInt()
        out = i.readInt(); scl = i.readInt(); sda = i.readInt(); phase = i.readInt(); rxKind = i.readInt()
        afterAck = i.readInt(); bits = i.readInt(); shift = i.readInt(); addr = i.readInt(); cur = i.readInt()
        continueRead = i.readBoolean()
    }

    fun write(newScl: Int, newSda: Int) {
        if (scl == 1 && newScl == 1) {
            if (sda == 1 && newSda == 0) start()
            else if (sda == 0 && newSda == 1) stop()
        }
        if (scl == 0 && newScl == 1) rising(newSda)
        else if (scl == 1 && newScl == 0) falling()
        scl = newScl
        sda = newSda
    }

    private fun start() { starts++; phase = 1; rxKind = 0; bits = 0; shift = 0; out = 1 }
    private fun stop() { phase = 0; out = 1 }

    private fun rising(bit: Int) {
        when (phase) {
            1 -> {
                shift = ((shift shl 1) or bit) and 0xFF
                bits++
                if (bits == 8) handleByte(shift)
            }
            4 -> continueRead = (bit == 0)
        }
    }

    private fun falling() {
        when (phase) {
            1 -> if (bits == 8) {
                if (afterAck == 0) { phase = 0; out = 1 } else { phase = 2; out = 0 }
            }
            2 -> {
                out = 1
                if (afterAck == 2) {
                    cur = data[addr and mask].toInt() and 0xFF
                    phase = 3; bits = 0; out = (cur shr 7) and 1
                } else {
                    phase = 1; bits = 0; shift = 0
                }
            }
            3 -> {
                bits++
                if (bits == 8) {
                    txBytes++
                    addr = (addr + 1) and mask // the chip advances its address after every byte sent, ACK or not
                    phase = 4; out = 1
                } else out = (cur shr (7 - bits)) and 1
            }
            4 -> if (continueRead) {
                cur = data[addr and mask].toInt() and 0xFF
                phase = 3; bits = 0; out = (cur shr 7) and 1
            } else {
                phase = 0; out = 1
            }
        }
    }

    private fun handleByte(b: Int) {
        rxBytes++
        if (!detected && rxKind == 0) {
            detected = true
            is01 = (b and 0xFE) != 0xA0
            mask = if (is01) 0x7F else 0xFF
        }
        if (is01) {
            if (rxKind == 0) {
                addr = (b shr 1) and 0x7F
                if ((b and 1) != 0) afterAck = 2 else { rxKind = 2; afterAck = 1 }
            } else {
                data[addr and mask] = b.toByte()
                addr = (addr + 1) and mask
                writes++; onWrite()
                afterAck = 1
            }
        } else {
            when (rxKind) {
                0 -> {
                    if ((b shr 4) != 0xA) afterAck = 0
                    else if ((b and 1) != 0) afterAck = 2
                    else { rxKind = 1; afterAck = 1 }
                }
                1 -> { addr = b; rxKind = 2; afterAck = 1 }
                else -> {
                    data[addr and mask] = b.toByte()
                    addr = (addr and 0xF8) or ((addr + 1) and 7)
                    writes++; onWrite()
                    afterAck = 1
                }
            }
        }
    }
}
