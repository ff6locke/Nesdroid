package com.nesdroid.core

import java.util.Arrays

/**
 * 2C02 PPU. Renders each visible scanline at dot 0 (using the loopy v/t registers),
 * with sprite-0 hit timed to its real dot and the MMC3 scanline counter clocked at dot 260.
 */
class Ppu(private val m: Mapper) {
    val fb = IntArray(256 * 240)
    val oam = IntArray(256)
    var oamAddr = 0
    var frame = 0L
    var nmiPending = false

    private val vram = ByteArray(0x1000)
    private val pal = IntArray(32)
    private var ctrl = 0
    private var mask = 0
    private var status = 0
    private var v = 0
    private var t = 0
    private var fineX = 0
    private var w = false
    private var buf = 0
    private var scanline = 261
    private var dot = 0
    private var odd = false
    private var s0Dot = -1
    private val bgPix = IntArray(256)
    private val spPix = IntArray(256)
    private val spFlags = IntArray(256)

    fun reset() {
        ctrl = 0; mask = 0; w = false; buf = 0; nmiPending = false
        scanline = 261; dot = 0
    }

    // ---------- registers ----------
    fun readReg(r: Int): Int {
        when (r) {
            2 -> {
                val s = (status and 0xE0) or (buf and 0x1F)
                status = status and 0x7F
                w = false
                return s
            }
            4 -> {
                val d = oam[oamAddr]
                return if ((oamAddr and 3) == 2) d and 0xE3 else d
            }
            7 -> {
                val a = v and 0x3FFF
                val ret: Int
                if (a >= 0x3F00) {
                    ret = pal[palIdx(a)] and (if ((mask and 1) != 0) 0x30 else 0x3F)
                    buf = read(a - 0x1000)
                } else {
                    ret = buf
                    buf = read(a)
                }
                v = (v + (if ((ctrl and 4) != 0) 32 else 1)) and 0x7FFF
                return ret
            }
        }
        return 0
    }

    fun writeReg(r: Int, d0: Int) {
        val d = d0 and 0xFF
        when (r) {
            0 -> {
                val was = (ctrl and 0x80) != 0
                ctrl = d
                t = (t and 0xF3FF) or ((d and 3) shl 10)
                if (!was && (d and 0x80) != 0 && (status and 0x80) != 0) nmiPending = true
            }
            1 -> mask = d
            3 -> oamAddr = d
            4 -> { oam[oamAddr] = d; oamAddr = (oamAddr + 1) and 0xFF }
            5 -> if (!w) {
                t = (t and 0xFFE0) or (d shr 3)
                fineX = d and 7
                w = true
            } else {
                t = (t and 0x8C1F) or ((d and 7) shl 12) or ((d and 0xF8) shl 2)
                w = false
            }
            6 -> if (!w) {
                t = (t and 0x00FF) or ((d and 0x3F) shl 8)
                w = true
            } else {
                t = (t and 0xFF00) or d
                v = t
                w = false
            }
            7 -> {
                write(v, d)
                v = (v + (if ((ctrl and 4) != 0) 32 else 1)) and 0x7FFF
            }
        }
    }

    // ---------- memory ----------
    private fun palIdx(a: Int): Int {
        var i = a and 0x1F
        if (i >= 0x10 && (i and 3) == 0) i -= 0x10
        return i
    }

    private fun ntIndex(addr: Int): Int {
        val a = addr and 0xFFF
        val nt = a shr 10
        val page = when (m.mirroring) { 0 -> nt shr 1; 1 -> nt and 1; 2 -> 0; 3 -> 1; else -> nt }
        return page * 0x400 + (a and 0x3FF)
    }

    private fun read(addr: Int): Int {
        val a = addr and 0x3FFF
        return when {
            a < 0x2000 -> m.ppuRead(a)
            a < 0x3F00 -> vram[ntIndex(a)].toInt() and 0xFF
            else -> pal[palIdx(a)]
        }
    }

    private fun write(addr: Int, d: Int) {
        val a = addr and 0x3FFF
        when {
            a < 0x2000 -> m.ppuWrite(a, d)
            a < 0x3F00 -> vram[ntIndex(a)] = d.toByte()
            else -> pal[palIdx(a)] = d and 0x3F
        }
    }

    // ---------- timing ----------
    fun tick(n: Int) {
        var left = n
        while (left > 0) {
            // Fast-forward over dots where nothing can happen.
            if (scanline < 240 && dot in 1..254) {
                var lim = 255 - dot
                if (s0Dot >= dot) lim = minOf(lim, s0Dot - dot)
                val k = minOf(left, lim)
                if (k > 0) { dot += k; left -= k; continue }
            } else if (scanline in 242..260 && dot < 340) {
                val k = minOf(left, 340 - dot)
                dot += k; left -= k
                continue
            }
            step()
            left--
        }
    }

    private fun step() {
        val rendering = (mask and 0x18) != 0
        if (scanline < 240) {
            if (dot == 0) {
                if (rendering) renderLine(scanline) else fillBackdrop(scanline)
            } else if (dot == s0Dot) {
                status = status or 0x40
                s0Dot = -1
            }
            if (rendering) {
                if (dot == 256) incY()
                else if (dot == 257) copyX()
                else if (dot == 260) m.scanline()
            }
        } else if (scanline == 241) {
            if (dot == 1) {
                status = status or 0x80
                if ((ctrl and 0x80) != 0) nmiPending = true
                frame++
            }
        } else if (scanline == 261) {
            if (dot == 1) { status = status and 0x1F; s0Dot = -1 }
            if (rendering) {
                if (dot == 257) copyX()
                else if (dot == 260) m.scanline()
                else if (dot in 280..304) copyY()
                if (dot == 339 && odd) dot++
            }
        }
        dot++
        if (dot > 340) {
            dot = 0
            scanline++
            if (scanline > 261) { scanline = 0; odd = !odd }
        }
    }

    private fun incY() {
        if ((v and 0x7000) != 0x7000) v += 0x1000
        else {
            v = v and 0x8FFF
            var cy = (v and 0x03E0) shr 5
            if (cy == 29) { cy = 0; v = v xor 0x0800 }
            else if (cy == 31) cy = 0
            else cy++
            v = (v and 0xFC1F) or (cy shl 5)
        }
    }
    private fun copyX() { v = (v and 0xFBE0) or (t and 0x041F) }
    private fun copyY() { v = (v and 0x841F) or (t and 0x7BE0) }

    private fun fillBackdrop(y: Int) {
        val g = if ((mask and 1) != 0) 0x30 else 0x3F
        Arrays.fill(fb, y * 256, y * 256 + 256, COLORS[pal[0] and g])
    }

    private fun renderLine(y: Int) {
        val bgOn = (mask and 8) != 0
        val spOn = (mask and 0x10) != 0
        val base = y * 256

        if (bgOn) {
            val patBase = if ((ctrl and 0x10) != 0) 0x1000 else 0
            val fy = (v shr 12) and 7
            var cx = v and 31
            val cy = (v shr 5) and 31
            var nt = (v shr 10) and 3
            var x0 = -fineX
            for (tile in 0..32) {
                val ntBase = 0x2000 or (nt shl 10)
                val tileId = vram[ntIndex(ntBase or (cy shl 5) or cx)].toInt() and 0xFF
                val attr = vram[ntIndex(ntBase or 0x3C0 or ((cy shr 2) shl 3) or (cx shr 2))].toInt() and 0xFF
                val palSel = (attr shr (((cy and 2) shl 1) or (cx and 2))) and 3
                val a = patBase + tileId * 16 + fy
                val lo = m.ppuRead(a)
                val hi = m.ppuRead(a + 8)
                for (px in 0..7) {
                    val sx = x0 + px
                    if (sx in 0..255) {
                        val bit = 7 - px
                        val c = ((lo shr bit) and 1) or (((hi shr bit) and 1) shl 1)
                        bgPix[sx] = if (c == 0) 0 else (palSel shl 2) or c
                    }
                }
                x0 += 8
                cx++
                if (cx == 32) { cx = 0; nt = nt xor 1 }
            }
            if ((mask and 2) == 0) for (i in 0..7) bgPix[i] = 0
        } else Arrays.fill(bgPix, 0)

        Arrays.fill(spPix, 0)
        if (spOn) {
            val h = if ((ctrl and 0x20) != 0) 16 else 8
            var count = 0
            for (i in 0 until 64) {
                val o = i * 4
                val row = y - oam[o] - 1
                if (row < 0 || row >= h) continue
                if (count == 8) { status = status or 0x20; break }
                count++
                val tile = oam[o + 1]
                val attr = oam[o + 2]
                val sx = oam[o + 3]
                val r = if ((attr and 0x80) != 0) h - 1 - row else row
                val addr = if (h == 16)
                    ((tile and 1) shl 12) + ((tile and 0xFE) + (r shr 3)) * 16 + (r and 7)
                else
                    (if ((ctrl and 8) != 0) 0x1000 else 0) + tile * 16 + r
                val lo = m.ppuRead(addr)
                val hi = m.ppuRead(addr + 8)
                val flipH = (attr and 0x40) != 0
                for (px in 0..7) {
                    val x = sx + px
                    if (x > 255) break
                    if (x < 8 && (mask and 4) == 0) continue
                    val bit = if (flipH) px else 7 - px
                    val c = ((lo shr bit) and 1) or (((hi shr bit) and 1) shl 1)
                    if (c == 0 || spPix[x] != 0) continue
                    spPix[x] = ((attr and 3) shl 2) or c
                    spFlags[x] = (if ((attr and 0x20) != 0) 1 else 0) or (if (i == 0) 2 else 0)
                }
            }
        }

        val g = if ((mask and 1) != 0) 0x30 else 0x3F
        for (x in 0 until 256) {
            val bg = bgPix[x]
            val sp = spPix[x]
            val bgC = bg and 3
            val spC = sp and 3
            val idx = if (spC == 0) {
                if (bgC == 0) 0 else bg
            } else if (bgC == 0) {
                0x10 or sp
            } else {
                if ((spFlags[x] and 1) != 0) bg else (0x10 or sp)
            }
            if (spC != 0 && bgC != 0 && (spFlags[x] and 2) != 0 && x != 255 &&
                s0Dot < 0 && (status and 0x40) == 0
            ) s0Dot = x + 1
            fb[base + x] = COLORS[pal[idx] and g]
        }
    }

    companion object {
        private val RAW = intArrayOf(
            0x666666, 0x002A88, 0x1412A7, 0x3B00A4, 0x5C007E, 0x6E0040, 0x6C0600, 0x561D00,
            0x333500, 0x0B4800, 0x005200, 0x004F08, 0x00404D, 0x000000, 0x000000, 0x000000,
            0xADADAD, 0x155FD9, 0x4240FF, 0x7527FE, 0xA01ACC, 0xB71E7B, 0xB53120, 0x994E00,
            0x6B6D00, 0x388700, 0x0C9300, 0x008F32, 0x007C8D, 0x000000, 0x000000, 0x000000,
            0xFFFEFF, 0x64B0FF, 0x9290FF, 0xC676FF, 0xF36AFF, 0xFE6ECC, 0xFE8170, 0xEA9E22,
            0xBCBE00, 0x88D800, 0x5CE430, 0x45E082, 0x48CDDE, 0x4F4F4F, 0x000000, 0x000000,
            0xFFFEFF, 0xC0DFFF, 0xD3D2FF, 0xE8C8FF, 0xFBC2FF, 0xFEC4EA, 0xFECCC5, 0xF7D8A5,
            0xE4E594, 0xCFEF96, 0xBDF4AB, 0xB3F3CC, 0xB5EBF2, 0xB8B8B8, 0x000000, 0x000000
        )
        private val COLORS = IntArray(64) { RAW[it] or (0xFF shl 24) }
    }
}
