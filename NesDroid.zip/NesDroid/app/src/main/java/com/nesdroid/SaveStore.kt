package com.nesdroid

import com.nesdroid.core.Cartridge
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Persists cartridge save RAM / EEPROM (<rom-crc>.sav) and save states (<rom-crc>.s1 .. .s10) in the
 * app's private storage, and mirrors them into a user-chosen folder (if set) so they survive uninstalling.
 */
class SaveStore(private val dir: File) {
    init { dir.mkdirs() }

    private val stateDir = File(dir.parentFile ?: dir, "states").also { it.mkdirs() }
    @Volatile private var mirror: MirrorFolder? = null
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "save-mirror").also { it.isDaemon = true } }
    private val stateName = Regex("""\.s(10|[1-9])$""")

    val hasMirror: Boolean get() = mirror != null

    fun setMirror(m: MirrorFolder?) { mirror = m }

    private fun isSaveName(n: String) = n.endsWith(".sav") || stateName.containsMatchIn(n)

    private fun mirrorPut(name: String, data: ByteArray) {
        val m = mirror ?: return
        io.execute { try { m.put(name, data) } catch (e: Exception) { /* folder gone: ignore */ } }
    }

    /** Waits (briefly) for queued copies into the save folder, e.g. before the app goes to the background. */
    fun waitIdle() {
        if (mirror == null) return
        try { io.submit {}.get(3, TimeUnit.SECONDS) } catch (e: Exception) { }
    }

    /**
     * Two-way sync between local storage and the save folder: newer/missing files in the folder are
     * restored locally, newer/missing local files are copied to the folder. Returns files restored locally.
     */
    fun sync(): Int {
        val m = mirror ?: return 0
        val remote = m.list()
        val local = HashMap<String, File>()
        for (f in (dir.listFiles() ?: emptyArray()) + (stateDir.listFiles() ?: emptyArray())) {
            if (f.isFile && isSaveName(f.name)) local[f.name] = f
        }
        var restored = 0
        for ((name, e) in remote) {
            if (!isSaveName(name)) continue
            val lf = local[name]
            if (lf == null || e.modified > lf.lastModified() + 2000) {
                val data = m.read(e) ?: continue
                val target = if (name.endsWith(".sav")) File(dir, name) else File(stateDir, name)
                target.writeBytes(data)
                if (e.modified > 0) target.setLastModified(e.modified)
                restored++
            }
        }
        for ((name, lf) in local) {
            val e = remote[name]
            if (e == null || lf.lastModified() > e.modified + 2000) m.put(name, lf.readBytes())
        }
        return restored
    }

    // ---------- battery / EEPROM save ----------
    private fun fileFor(cart: Cartridge) = File(dir, "${cart.crc}.sav")

    fun load(cart: Cartridge) {
        val f = fileFor(cart)
        if (f.exists()) {
            val b = f.readBytes()
            val ram = cart.mapper.prgRam
            System.arraycopy(b, 0, ram, 0, minOf(b.size, ram.size))
        }
    }

    fun info(cart: Cartridge): String {
        val f = fileFor(cart)
        val where = if (hasMirror) " (also copied to your save folder)" else " (app storage only)"
        return if (f.exists()) "Save file: ${f.length()} bytes, saved ${(System.currentTimeMillis() - f.lastModified()) / 1000}s ago$where"
        else "Save file: none yet"
    }

    fun save(cart: Cartridge) {
        val bytes = cart.mapper.prgRam.copyOf(cart.mapper.saveSize)
        val tmp = File(dir, "${cart.crc}.tmp")
        tmp.writeBytes(bytes)
        tmp.renameTo(fileFor(cart))
        mirrorPut("${cart.crc}.sav", bytes)
    }

    // ---------- save states ----------
    private fun stateFile(cart: Cartridge, slot: Int) = File(stateDir, "${cart.crc}.s$slot")

    fun writeState(cart: Cartridge, slot: Int, data: ByteArray) {
        val tmp = File(stateDir, "${cart.crc}.tmp")
        tmp.writeBytes(data)
        tmp.renameTo(stateFile(cart, slot))
        mirrorPut("${cart.crc}.s$slot", data)
    }

    fun readState(cart: Cartridge, slot: Int): ByteArray? {
        val f = stateFile(cart, slot)
        return if (f.exists()) f.readBytes() else null
    }

    /** Last-modified time of the slot's file, or 0 if the slot is empty. */
    fun stateTime(cart: Cartridge, slot: Int): Long {
        val f = stateFile(cart, slot)
        return if (f.exists()) f.lastModified() else 0L
    }
}
