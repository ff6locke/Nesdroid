package com.nesdroid

import com.nesdroid.core.Cartridge
import java.io.File

/** Persists cartridge save RAM ($6000-$7FFF) as <rom-crc>.sav in the app's private storage. */
class SaveStore(private val dir: File) {
    init { dir.mkdirs() }

    private fun fileFor(cart: Cartridge) = File(dir, "${cart.crc}.sav")

    fun load(cart: Cartridge) {
        val f = fileFor(cart)
        if (f.exists()) {
            val b = f.readBytes()
            val ram = cart.mapper.prgRam
            System.arraycopy(b, 0, ram, 0, minOf(b.size, ram.size))
        }
    }

    fun info(cart: Cartridge): String {
        val f = fileFor(cart)
        return if (f.exists()) "Save file: ${f.length()} bytes, saved ${(System.currentTimeMillis() - f.lastModified()) / 1000}s ago"
        else "Save file: none yet"
    }

    fun save(cart: Cartridge) {
        val tmp = File(dir, "${cart.crc}.tmp")
        tmp.writeBytes(cart.mapper.prgRam.copyOf(cart.mapper.saveSize))
        tmp.renameTo(fileFor(cart))
    }
}
