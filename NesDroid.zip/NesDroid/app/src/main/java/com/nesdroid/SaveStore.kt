package com.nesdroid

import com.nesdroid.core.Cartridge
import java.io.File

/** Persists cartridge save RAM ($6000-$7FFF) as <rom-crc>.sav in the app's private storage. */
class SaveStore(private val dir: File) {
    init { dir.mkdirs() }

    private val stateDir = File(dir.parentFile ?: dir, "states").also { it.mkdirs() }

    private fun stateFile(cart: Cartridge, slot: Int) = File(stateDir, "${cart.crc}.s$slot")

    fun writeState(cart: Cartridge, slot: Int, data: ByteArray) {
        val tmp = File(stateDir, "${cart.crc}.tmp")
        tmp.writeBytes(data)
        tmp.renameTo(stateFile(cart, slot))
    }

    fun readState(cart: Cartridge, slot: Int): ByteArray? {
        val f = stateFile(cart, slot)
        return if (f.exists()) f.readBytes() else null
    }

    /** Last-modified time of the slot's file, or 0 if the slot is empty. */
    fun stateTime(cart: Cartridge, slot: Int): Long {
        val f = stateFile(cart, slot)
        return if (f.exists()) f.lastModified() else 0L
    }

    private fun fileFor(cart: Cartridge) = File(dir, "${cart.crc}.sav")

    fun load(cart: Cartridge) {
        val f = fileFor(cart)
        if (f.exists()) {
            val b = f.readBytes()
            val ram = cart.mapper.prgRam
            System.arraycopy(b, 0, ram, 0, minOf(b.size, ram.size))
        }
    }

    fun info(cart: Cartridge): String {
        val f = fileFor(cart)
        return if (f.exists()) "Save file: ${f.length()} bytes, saved ${(System.currentTimeMillis() - f.lastModified()) / 1000}s ago"
        else "Save file: none yet"
    }

    fun save(cart: Cartridge) {
        val tmp = File(dir, "${cart.crc}.tmp")
        tmp.writeBytes(cart.mapper.prgRam.copyOf(cart.mapper.saveSize))
        tmp.renameTo(fileFor(cart))
    }
}
