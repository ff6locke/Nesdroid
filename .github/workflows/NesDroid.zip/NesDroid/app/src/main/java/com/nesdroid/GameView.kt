package com.nesdroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView

/** Draws the NES frame plus on-screen touch controls, and turns touches into pad bits. */
class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback {
    @Volatile var buttons = 0
    var onMenu: (() -> Unit)? = null
    var hint: String = "Tap the menu button to open a ROM"
    var hasGame = false

    private val bmp = Bitmap.createBitmap(256, 240, Bitmap.Config.ARGB_8888)
    private val src = Rect(0, 0, 256, 240)
    private val dst = Rect()
    private val gamePaint = Paint()
    private val ctl = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }
    private val d = resources.displayMetrics.density
    private var ready = false

    private var dx = 0f; private var dy = 0f; private var dr = 0f
    private var ax = 0f; private var ay = 0f; private var bx = 0f; private var by = 0f; private var br = 0f
    private val startR = RectF(); private val selectR = RectF(); private val menuR = RectF()

    companion object {
        const val A = 1; const val B = 2; const val SELECT = 4; const val START = 8
        const val UP = 16; const val DOWN = 32; const val LEFT = 64; const val RIGHT = 128
    }

    init { holder.addCallback(this) }

    override fun surfaceCreated(h: SurfaceHolder) { ready = true }
    override fun surfaceDestroyed(h: SurfaceHolder) { ready = false }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
        layoutControls(w, hh)
        present(null)
    }

    private fun layoutControls(w: Int, h: Int) {
        val land = w > h
        val btnW = 84 * d; val btnH = 34 * d
        if (!land) {
            val top = 56 * d
            val gh = w * 240f / 256f
            dst.set(0, top.toInt(), w, (top + gh).toInt())
            val ctlTop = top + gh
            val cy = ctlTop + (h - ctlTop) * 0.48f
            dr = minOf(w * 0.2f, (h - ctlTop) * 0.36f)
            dx = w * 0.25f; dy = cy
            br = dr * 0.55f
            ax = w * 0.86f; ay = cy - br * 0.8f
            bx = w * 0.64f; by = cy + br * 0.8f
            menuR.set(w - 56 * d, 6 * d, w - 8 * d, 54 * d)
        } else {
            val gw = h * 256f / 240f
            val left = (w - gw) / 2f
            dst.set(left.toInt(), 0, (left + gw).toInt(), h)
            dr = h * 0.2f
            dx = dr * 1.5f; dy = h * 0.66f
            br = h * 0.1f
            ax = w - br * 1.8f; ay = h * 0.56f
            bx = ax - br * 2.4f; by = ay + br * 1.4f
            menuR.set(w / 2f - 24 * d, 4 * d, w / 2f + 24 * d, 52 * d)
        }
        val sy = h - 14 * d - btnH
        selectR.set(w / 2f - 8 * d - btnW, sy, w / 2f - 8 * d, sy + btnH)
        startR.set(w / 2f + 8 * d, sy, w / 2f + 8 * d + btnW, sy + btnH)
    }

    @Synchronized
    fun present(fb: IntArray?) {
        if (!ready) return
        if (fb != null) bmp.setPixels(fb, 0, 256, 0, 0, 256, 240)
        val c = holder.lockCanvas() ?: return
        try {
            c.drawColor(Color.BLACK)
            if (hasGame) c.drawBitmap(bmp, src, dst, gamePaint)
            else {
                txt.textSize = 16 * d
                c.drawText(hint, dst.centerX().toFloat(), dst.centerY().toFloat(), txt)
            }
            drawControls(c)
        } finally {
            holder.unlockCanvasAndPost(c)
        }
    }

    private fun fill(c: Canvas, pressed: Boolean) {
        ctl.style = Paint.Style.FILL
        ctl.color = if (pressed) Color.argb(150, 255, 255, 255) else Color.argb(60, 255, 255, 255)
    }

    private fun drawControls(c: Canvas) {
        val b = buttons
        // D-pad
        ctl.style = Paint.Style.STROKE; ctl.strokeWidth = 2 * d; ctl.color = Color.argb(90, 255, 255, 255)
        c.drawCircle(dx, dy, dr, ctl)
        val t = dr * 0.34f
        fill(c, (b and UP) != 0); c.drawRect(dx - t, dy - dr * 0.95f, dx + t, dy - t * 0.3f, ctl)
        fill(c, (b and DOWN) != 0); c.drawRect(dx - t, dy + t * 0.3f, dx + t, dy + dr * 0.95f, ctl)
        fill(c, (b and LEFT) != 0); c.drawRect(dx - dr * 0.95f, dy - t, dx - t * 0.3f, dy + t, ctl)
        fill(c, (b and RIGHT) != 0); c.drawRect(dx + t * 0.3f, dy - t, dx + dr * 0.95f, dy + t, ctl)
        // A / B
        txt.textSize = br * 0.8f
        fill(c, (b and A) != 0); c.drawCircle(ax, ay, br, ctl)
        c.drawText("A", ax, ay + br * 0.28f, txt)
        fill(c, (b and B) != 0); c.drawCircle(bx, by, br, ctl)
        c.drawText("B", bx, by + br * 0.28f, txt)
        // Start / Select
        txt.textSize = 13 * d
        fill(c, (b and SELECT) != 0); c.drawRoundRect(selectR, 16 * d, 16 * d, ctl)
        c.drawText("SELECT", selectR.centerX(), selectR.centerY() + 5 * d, txt)
        fill(c, (b and START) != 0); c.drawRoundRect(startR, 16 * d, 16 * d, ctl)
        c.drawText("START", startR.centerX(), startR.centerY() + 5 * d, txt)
        // Menu
        fill(c, false); c.drawRoundRect(menuR, 10 * d, 10 * d, ctl)
        txt.textSize = 24 * d
        c.drawText("\u2630", menuR.centerX(), menuR.centerY() + 8 * d, txt)
    }

    private fun near(x: Float, y: Float, cx: Float, cy: Float, r: Float): Boolean {
        val a = x - cx; val b = y - cy
        return a * a + b * b <= r * r
    }

    private fun hit(x: Float, y: Float): Int {
        var m = 0
        if (near(x, y, dx, dy, dr * 1.5f)) {
            val t = dr * 0.3f
            if (x - dx < -t) m = m or LEFT
            if (x - dx > t) m = m or RIGHT
            if (y - dy < -t) m = m or UP
            if (y - dy > t) m = m or DOWN
        }
        if (near(x, y, ax, ay, br * 1.4f)) m = m or A
        if (near(x, y, bx, by, br * 1.4f)) m = m or B
        if (startR.contains(x, y)) m = m or START
        if (selectR.contains(x, y)) m = m or SELECT
        return m
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val act = e.actionMasked
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex
            if (menuR.contains(e.getX(i), e.getY(i))) post { onMenu?.invoke() }
        }
        var mask = 0
        if (act != MotionEvent.ACTION_UP && act != MotionEvent.ACTION_CANCEL) {
            val skip = if (act == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
            for (i in 0 until e.pointerCount) {
                if (i == skip) continue
                mask = mask or hit(e.getX(i), e.getY(i))
            }
        }
        buttons = mask
        return true
    }
}
