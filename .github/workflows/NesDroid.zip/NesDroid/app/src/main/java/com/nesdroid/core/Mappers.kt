package com.nesdroid.core

/**
 * Cartridge board. mirroring: 0=horizontal 1=vertical 2=single(low) 3=single(high) 4=four-screen.
 * PRG RAM ($6000-$7FFF) lives here and is what gets persisted as the save file.
 */
abstract class Mapper(protected val cart: Cartridge) {
    val prgRam = ByteArray(0x2000)
    @Volatile var ramDirty = false
    var irq = false
    var mirroring = if (cart.fourScreen) 4 else cart.mirroring
    protected val prg: ByteArray = cart.prg
    protected val chr: ByteArray = cart.chr

    open fun scanline() {}

    fun cpuRead(addr: Int): Int =
        if (addr >= 0x8000) prgRead(addr)
        else if (addr >= 0x6000) prgRam[addr and 0x1FFF].toInt() and 0xFF
        else 0

    fun cpuWrite(addr: Int, v: Int) {
        if (addr >= 0x8000) regWrite(addr, v)
        else if (addr >= 0x6000) {
            prgRam[addr and 0x1FFF] = v.toByte()
            ramDirty = true
        }
    }

    protected abstract fun prgRead(addr: Int): Int
    protected abstract fun regWrite(addr: Int, v: Int)
    protected open fun chrIndex(addr: Int): Int = addr and 0x1FFF

    fun ppuRead(addr: Int): Int = chr[chrIndex(addr)].toInt() and 0xFF
    fun ppuWrite(addr: Int, v: Int) {
        if (cart.chrIsRam) chr[chrIndex(addr)] = v.toByte()
    }
}

class Mapper0(c: Cartridge) : Mapper(c) {
    override fun prgRead(addr: Int) = prg[(addr - 0x8000) % prg.size].toInt() and 0xFF
    override fun regWrite(addr: Int, v: Int) {}
}

/** MMC1 (SxROM) */
class Mapper1(c: Cartridge) : Mapper(c) {
    private var shift = 0x10
    private var control = 0x0C
    private var chr0 = 0
    private var chr1 = 0
    private var prgB = 0

    init { updateMirror() }

    private fun updateMirror() {
        mirroring = when (control and 3) { 0 -> 2; 1 -> 3; 2 -> 1; else -> 0 }
    }

    override fun regWrite(addr: Int, v: Int) {
        if ((v and 0x80) != 0) {
            shift = 0x10
            control = control or 0x0C
            updateMirror()
            return
        }
        val last = (shift and 1) != 0
        shift = (shift shr 1) or ((v and 1) shl 4)
        if (last) {
            when ((addr shr 13) and 3) {
                0 -> { control = shift; updateMirror() }
                1 -> chr0 = shift
                2 -> chr1 = shift
                else -> prgB = shift
            }
            shift = 0x10
        }
    }

    override fun prgRead(addr: Int): Int {
        val n16 = prg.size / 0x4000
        val bank = when ((control shr 2) and 3) {
            0, 1 -> (prgB and 0x0E) + (if (addr >= 0xC000) 1 else 0)
            2 -> if (addr < 0xC000) 0 else (prgB and 0x0F)
            else -> if (addr < 0xC000) (prgB and 0x0F) else n16 - 1
        }
        return prg[(bank % n16) * 0x4000 + (addr and 0x3FFF)].toInt() and 0xFF
    }

    override fun chrIndex(addr: Int): Int {
        val n4 = chr.size / 0x1000
        val slot = (addr shr 12) and 1
        val bank = if ((control and 0x10) == 0) (chr0 and 0x1E) + slot else if (slot == 0) chr0 else chr1
        return (bank % n4) * 0x1000 + (addr and 0xFFF)
    }
}

/** UxROM */
class Mapper2(c: Cartridge) : Mapper(c) {
    private var bank = 0
    override fun prgRead(addr: Int): Int {
        val n16 = prg.size / 0x4000
        val b = if (addr < 0xC000) bank % n16 else n16 - 1
        return prg[b * 0x4000 + (addr and 0x3FFF)].toInt() and 0xFF
    }
    override fun regWrite(addr: Int, v: Int) { bank = v and 0xFF }
}

/** CNROM */
class Mapper3(c: Cartridge) : Mapper(c) {
    private var bank = 0
    override fun prgRead(addr: Int) = prg[(addr - 0x8000) % prg.size].toInt() and 0xFF
    override fun regWrite(addr: Int, v: Int) { bank = v and 0xFF }
    override fun chrIndex(addr: Int): Int = (bank % (chr.size / 0x2000)) * 0x2000 + (addr and 0x1FFF)
}

/** MMC3 (TxROM) - used by most larger Bandai/Tose DBZ-era titles. */
class Mapper4(c: Cartridge) : Mapper(c) {
    private var bankSel = 0
    private val regs = IntArray(8)
    private var latch = 0
    private var counter = 0
    private var reload = false
    private var irqEnable = false

    override fun regWrite(addr: Int, v: Int) {
        when (addr and 0xE001) {
            0x8000 -> bankSel = v
            0x8001 -> regs[bankSel and 7] = v
            0xA000 -> if (!cart.fourScreen) mirroring = if ((v and 1) != 0) 0 else 1
            0xA001 -> {}
            0xC000 -> latch = v
            0xC001 -> { counter = 0; reload = true }
            0xE000 -> { irqEnable = false; irq = false }
            0xE001 -> irqEnable = true
        }
    }

    override fun scanline() {
        if (counter == 0 || reload) {
            counter = latch
            reload = false
        } else counter--
        if (counter == 0 && irqEnable) irq = true
    }

    override fun prgRead(addr: Int): Int {
        val n8 = prg.size / 0x2000
        val swap = (bankSel and 0x40) != 0
        val bank = when ((addr shr 13) and 3) {
            0 -> if (swap) n8 - 2 else regs[6]
            1 -> regs[7]
            2 -> if (swap) regs[6] else n8 - 2
            else -> n8 - 1
        }
        return prg[(bank % n8) * 0x2000 + (addr and 0x1FFF)].toInt() and 0xFF
    }

    override fun chrIndex(addr: Int): Int {
        var slot = (addr shr 10) and 7
        if ((bankSel and 0x80) != 0) slot = slot xor 4
        val bank = when (slot) {
            0 -> regs[0] and 0xFE
            1 -> regs[0] or 1
            2 -> regs[1] and 0xFE
            3 -> regs[1] or 1
            4 -> regs[2]
            5 -> regs[3]
            6 -> regs[4]
            else -> regs[5]
        }
        return (bank % (chr.size / 0x400)) * 0x400 + (addr and 0x3FF)
    }
}

/** AxROM */
class Mapper7(c: Cartridge) : Mapper(c) {
    private var bank = 0
    override fun prgRead(addr: Int): Int {
        val n32 = (prg.size / 0x8000).coerceAtLeast(1)
        return prg[(bank % n32) * 0x8000 + (addr - 0x8000)].toInt() and 0xFF
    }
    override fun regWrite(addr: Int, v: Int) {
        bank = v and 7
        mirroring = if ((v and 0x10) != 0) 3 else 2
    }
}
