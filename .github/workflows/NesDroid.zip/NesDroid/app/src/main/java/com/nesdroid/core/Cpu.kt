package com.nesdroid.core

/** MOS 6502 (official opcodes; common unofficial NOPs are skipped correctly). */
class Cpu(private val nes: Nes) {
    private var a = 0
    private var x = 0
    private var y = 0
    private var sp = 0xFD
    private var pc = 0
    private var fc = false
    private var fz = false
    private var fi = true
    private var fd = false
    private var fv = false
    private var fn = false
    private var cross = false
    var stall = 0

    fun reset() {
        a = 0; x = 0; y = 0; sp = 0xFD
        fc = false; fz = false; fi = true; fd = false; fv = false; fn = false
        stall = 0
        pc = rd16(0xFFFC)
    }

    private fun rd(addr: Int): Int = nes.read(addr and 0xFFFF)
    private fun wr(addr: Int, v: Int) { nes.write(addr and 0xFFFF, v and 0xFF) }
    private fun rd16(addr: Int): Int = rd(addr) or (rd(addr + 1) shl 8)
    private fun rd16bug(p: Int): Int = rd(p) or (rd((p and 0xFF00) or ((p + 1) and 0xFF)) shl 8)
    private fun push(v: Int) { wr(0x100 + sp, v); sp = (sp - 1) and 0xFF }
    private fun pop(): Int { sp = (sp + 1) and 0xFF; return rd(0x100 + sp) }
    private fun push16(v: Int) { push(v shr 8); push(v and 0xFF) }
    private fun pop16(): Int { val lo = pop(); return lo or (pop() shl 8) }

    private fun getP(b: Boolean): Int =
        (if (fc) 1 else 0) or (if (fz) 2 else 0) or (if (fi) 4 else 0) or (if (fd) 8 else 0) or
            (if (b) 0x10 else 0) or 0x20 or (if (fv) 0x40 else 0) or (if (fn) 0x80 else 0)

    private fun setP(v: Int) {
        fc = (v and 1) != 0; fz = (v and 2) != 0; fi = (v and 4) != 0
        fd = (v and 8) != 0; fv = (v and 0x40) != 0; fn = (v and 0x80) != 0
    }

    private fun nz(v: Int) { fz = (v and 0xFF) == 0; fn = (v and 0x80) != 0 }

    // ---- addressing ----
    private fun aImm(): Int { val r = pc; pc = (pc + 1) and 0xFFFF; return r }
    private fun aZp(): Int = rd(aImm())
    private fun aZpx(): Int = (rd(aImm()) + x) and 0xFF
    private fun aZpy(): Int = (rd(aImm()) + y) and 0xFF
    private fun aAbs(): Int { val r = rd16(pc); pc = (pc + 2) and 0xFFFF; return r }
    private fun aAbsx(): Int {
        val b = aAbs(); val r = (b + x) and 0xFFFF
        cross = (b and 0xFF00) != (r and 0xFF00); return r
    }
    private fun aAbsy(): Int {
        val b = aAbs(); val r = (b + y) and 0xFFFF
        cross = (b and 0xFF00) != (r and 0xFF00); return r
    }
    private fun aIndx(): Int {
        val z = (rd(aImm()) + x) and 0xFF
        return rd(z) or (rd((z + 1) and 0xFF) shl 8)
    }
    private fun aIndy(): Int {
        val z = rd(aImm())
        val b = rd(z) or (rd((z + 1) and 0xFF) shl 8)
        val r = (b + y) and 0xFFFF
        cross = (b and 0xFF00) != (r and 0xFF00); return r
    }

    // ---- ALU ----
    private fun adc(m: Int) {
        val sum = a + m + (if (fc) 1 else 0)
        fv = ((a xor sum) and (m xor sum) and 0x80) != 0
        fc = sum > 0xFF
        a = sum and 0xFF
        nz(a)
    }
    private fun cmp(r: Int, m: Int) { fc = r >= m; nz((r - m) and 0xFF) }
    private fun bit(m: Int) { fz = (a and m) == 0; fv = (m and 0x40) != 0; fn = (m and 0x80) != 0 }
    private fun asl(m: Int): Int { fc = (m and 0x80) != 0; val r = (m shl 1) and 0xFF; nz(r); return r }
    private fun lsr(m: Int): Int { fc = (m and 1) != 0; val r = m shr 1; nz(r); return r }
    private fun rol(m: Int): Int {
        val c = if (fc) 1 else 0; fc = (m and 0x80) != 0
        val r = ((m shl 1) or c) and 0xFF; nz(r); return r
    }
    private fun ror(m: Int): Int {
        val c = if (fc) 0x80 else 0; fc = (m and 1) != 0
        val r = (m shr 1) or c; nz(r); return r
    }

    private fun interrupt(vec: Int): Int {
        push16(pc); push(getP(false)); fi = true
        pc = rd16(vec)
        return 7
    }

    /** Executes one instruction (or one stall cycle). Returns CPU cycles used. */
    fun step(): Int {
        if (stall > 0) { stall--; return 1 }
        val ppu = nes.ppu
        if (ppu.nmiPending) { ppu.nmiPending = false; return interrupt(0xFFFA) }
        if (!fi && nes.mapper.irq) return interrupt(0xFFFE)

        val op = rd(pc)
        pc = (pc + 1) and 0xFFFF
        cross = false

        if ((op and 0x1F) == 0x10) { // branches
            val flag = when (op shr 6) { 0 -> fn; 1 -> fv; 2 -> fc; else -> fz }
            val off = rd(pc).toByte().toInt()
            pc = (pc + 1) and 0xFFFF
            if (flag == ((op and 0x20) != 0)) {
                val np = (pc + off) and 0xFFFF
                val c = if ((np and 0xFF00) != (pc and 0xFF00)) 4 else 3
                pc = np
                return c
            }
            return 2
        }

        return when (op) {
            0x00 -> { pc = (pc + 1) and 0xFFFF; push16(pc); push(getP(true)); fi = true; pc = rd16(0xFFFE); 7 }
            0x20 -> { val t = rd16(pc); push16((pc + 1) and 0xFFFF); pc = t; 6 }
            0x40 -> { setP(pop()); pc = pop16(); 6 }
            0x60 -> { pc = (pop16() + 1) and 0xFFFF; 6 }
            0x08 -> { push(getP(true)); 3 }
            0x28 -> { setP(pop()); 4 }
            0x48 -> { push(a); 3 }
            0x68 -> { a = pop(); nz(a); 4 }
            0x88 -> { y = (y - 1) and 0xFF; nz(y); 2 }
            0xA8 -> { y = a; nz(y); 2 }
            0xC8 -> { y = (y + 1) and 0xFF; nz(y); 2 }
            0xE8 -> { x = (x + 1) and 0xFF; nz(x); 2 }
            0x8A -> { a = x; nz(a); 2 }
            0xAA -> { x = a; nz(x); 2 }
            0xCA -> { x = (x - 1) and 0xFF; nz(x); 2 }
            0x98 -> { a = y; nz(a); 2 }
            0xBA -> { x = sp; nz(x); 2 }
            0x9A -> { sp = x; 2 }
            0xEA -> 2
            0x18 -> { fc = false; 2 }
            0x38 -> { fc = true; 2 }
            0x58 -> { fi = false; 2 }
            0x78 -> { fi = true; 2 }
            0xB8 -> { fv = false; 2 }
            0xD8 -> { fd = false; 2 }
            0xF8 -> { fd = true; 2 }
            else -> decode(op)
        }
    }

    private fun decode(op: Int): Int {
        val cc = op and 3
        val bbb = (op shr 2) and 7
        val aaa = op shr 5
        when (cc) {
            1 -> {
                var cyc: Int
                val addr: Int
                when (bbb) {
                    0 -> { addr = aIndx(); cyc = 6 }
                    1 -> { addr = aZp(); cyc = 3 }
                    2 -> { addr = aImm(); cyc = 2 }
                    3 -> { addr = aAbs(); cyc = 4 }
                    4 -> { addr = aIndy(); cyc = 5 }
                    5 -> { addr = aZpx(); cyc = 4 }
                    6 -> { addr = aAbsy(); cyc = 4 }
                    else -> { addr = aAbsx(); cyc = 4 }
                }
                if (aaa == 4) { // STA
                    if (bbb != 2) wr(addr, a)
                    return if (bbb == 4) 6 else if (bbb >= 6) 5 else cyc
                }
                val m = rd(addr)
                if (cross && (bbb == 4 || bbb >= 6)) cyc++
                when (aaa) {
                    0 -> { a = a or m; nz(a) }
                    1 -> { a = a and m; nz(a) }
                    2 -> { a = a xor m; nz(a) }
                    3 -> adc(m)
                    5 -> { a = m; nz(a) }
                    6 -> cmp(a, m)
                    7 -> adc(m xor 0xFF)
                }
                return cyc
            }
            2 -> {
                if (bbb == 2) { // accumulator shifts (others handled earlier)
                    when (aaa) {
                        0 -> a = asl(a)
                        1 -> a = rol(a)
                        2 -> a = lsr(a)
                        3 -> a = ror(a)
                    }
                    return 2
                }
                if (bbb == 4 || bbb == 6) return 2 // KIL / unofficial NOP: treat as NOP
                if (bbb == 0 && aaa != 5) { pc = (pc + 1) and 0xFFFF; return 2 }
                if (aaa == 4 && bbb == 7) { pc = (pc + 2) and 0xFFFF; return 5 }
                val cyc: Int
                val addr: Int
                when (bbb) {
                    0 -> { addr = aImm(); cyc = 2 }
                    1 -> { addr = aZp(); cyc = 5 }
                    3 -> { addr = aAbs(); cyc = 6 }
                    5 -> { addr = if (aaa == 4 || aaa == 5) aZpy() else aZpx(); cyc = 6 }
                    else -> { addr = if (aaa == 5) aAbsy() else aAbsx(); cyc = 7 }
                }
                if (aaa == 4) { wr(addr, x); return if (bbb == 1) 3 else 4 }
                if (aaa == 5) {
                    x = rd(addr); nz(x)
                    return when (bbb) { 0 -> 2; 1 -> 3; 3 -> 4; 5 -> 4; else -> 4 + (if (cross) 1 else 0) }
                }
                val m = rd(addr)
                val r = when (aaa) {
                    0 -> asl(m); 1 -> rol(m); 2 -> lsr(m); 3 -> ror(m)
                    6 -> (m - 1) and 0xFF
                    else -> (m + 1) and 0xFF
                }
                if (aaa >= 6) nz(r)
                wr(addr, r)
                return cyc
            }
            0 -> {
                if (bbb == 3 && aaa == 2) { pc = aAbs(); return 3 }
                if (bbb == 3 && aaa == 3) { val p = aAbs(); pc = rd16bug(p); return 5 }
                val addr: Int
                val cyc: Int
                when (bbb) {
                    0 -> { addr = aImm(); cyc = 2 }
                    1 -> { addr = aZp(); cyc = 3 }
                    3 -> { addr = aAbs(); cyc = 4 }
                    5 -> { addr = aZpx(); cyc = 4 }
                    else -> { addr = aAbsx(); cyc = 4 }
                }
                when (aaa) {
                    1 -> if (bbb == 1 || bbb == 3) bit(rd(addr))
                    4 -> if (bbb == 1 || bbb == 3 || bbb == 5) wr(addr, y)
                    5 -> { y = rd(addr); nz(y) }
                    6 -> if (bbb == 0 || bbb == 1 || bbb == 3) cmp(y, rd(addr))
                    7 -> if (bbb == 0 || bbb == 1 || bbb == 3) cmp(x, rd(addr))
                    else -> {}
                }
                return if (bbb == 7 && cross) cyc + 1 else cyc
            }
            else -> { // cc == 3: unofficial opcodes, skipped as NOPs
                pc = (pc + (if (bbb == 3 || bbb == 6 || bbb == 7) 2 else 1)) and 0xFFFF
                return 3
            }
        }
    }
}
