# NesDroid

A from-scratch NES emulator for Android, written in Kotlin (no dependencies, no libretro).

## Features
- 6502 CPU, PPU (scanline renderer with sprite-0 hit), APU (2 pulse, triangle, noise)
- Mappers: 0 NROM, 1 MMC1, 2 UxROM, 3 CNROM, 4 MMC3 (with IRQ), 7 AxROM
- **Save RAM (battery saves)**: `$6000-$7FFF` is persisted automatically as `<rom-crc>.sav`
  (about 1.5 s after the game last wrote to it, when you pause/leave the app, and via menu > Save now)
- Export / import `.sav` files (8 KB raw, compatible with other emulators)
- Open `.nes` or `.zip`; remembers the last ROM
- Multitouch on-screen controls, portrait and landscape

## Build the APK
**Android Studio:** open this folder, let it sync, then Build > Build APK(s).

**GitHub (no PC needed):** push this folder to a GitHub repo. The *Build APK* workflow
(.github/workflows/build.yml) builds it; download `NesDroid-apk` from the Actions run.

**Command line:** with Gradle 8.7+ and JDK 17: `gradle assembleRelease`
(APK in `app/build/outputs/apk/release/`, debug-signed so it installs directly).

## Known limitations / TODO
- Not compiled or tested in the authoring environment: expect a few compile fixes.
- No DMC channel, no APU frame IRQ, unofficial CPU opcodes are treated as NOPs
- Mappers beyond the list above (MMC2/MMC5, VRC, etc.) are not supported
- Save states are not implemented; only battery RAM is persisted
- Bring your own legally obtained ROMs
